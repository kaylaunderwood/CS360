package com.example.kaylaunderwoodprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;


public class userData {

    private databaseHelper dbHelper;

    public userData(Context context) {
        dbHelper = new databaseHelper(context);
    }

    // Create new user
    public boolean registerUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(databaseHelper.USERNAME, username);
        values.put(databaseHelper.PASSWORD, password);

        long result = db.insert(databaseHelper.TABLE_USERS, null, values);
        return result != -1;
    }

    // Validate login
    public boolean loginUser(String username, String password) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String query = "SELECT * FROM " + databaseHelper.TABLE_USERS +
                " WHERE username=? AND password=?";
        Cursor cursor = db.rawQuery(query, new String[]{username, password});

        boolean isValid = cursor.getCount() > 0;
        cursor.close();
        return isValid;
    }
}
