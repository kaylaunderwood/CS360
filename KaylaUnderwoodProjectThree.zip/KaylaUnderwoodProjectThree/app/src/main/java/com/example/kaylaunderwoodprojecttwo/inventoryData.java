package com.example.kaylaunderwoodprojecttwo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
public class inventoryData {
    private databaseHelper dbHelper;

    public inventoryData(Context context) {
        dbHelper = new databaseHelper(context);
    }

    // CREATE
    public void addItem(String name, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(databaseHelper.ITEM_NAME, name);
        values.put(databaseHelper.ITEM_QUANTITY, quantity);
        db.insert(databaseHelper.TABLE_INVENTORY, null, values);
    }

    // READ
    public Cursor getAllItems() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        return db.rawQuery("SELECT * FROM " + databaseHelper.TABLE_INVENTORY, null);
    }

    // UPDATE
    public void updateItem(int id, int quantity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(databaseHelper.ITEM_QUANTITY, quantity);
        db.update(databaseHelper.TABLE_INVENTORY, values,
                databaseHelper.ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }

    // DELETE
    public void deleteItem(int id) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        db.delete(databaseHelper.TABLE_INVENTORY,
                databaseHelper.ITEM_ID + "=?", new String[]{String.valueOf(id)});
    }
}
